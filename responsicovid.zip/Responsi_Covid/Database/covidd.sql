-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2020 at 04:50 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covidd`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_statik`
--

CREATE TABLE `data_statik` (
  `id` int(11) NOT NULL,
  `id_negara` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `terkonfirmasi` int(11) NOT NULL,
  `positif` int(11) NOT NULL,
  `sembuh` int(11) NOT NULL,
  `meninggal` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_statik`
--

INSERT INTO `data_statik` (`id`, `id_negara`, `terkonfirmasi`, `positif`, `sembuh`, `meninggal`, `tanggal`) VALUES
(1, 'IDN', 12776, 9465, 2381, 930, '2020-05-07 13:11:20'),
(2, 'IDN', 12776, 9460, 2386, 930, '2020-05-08 06:00:00'),
(3, 'CHN', 9, 0, 0, 0, '2020-05-07 14:06:00'),
(4, 'CHN', 10000, 90, 9, 901, '2020-05-07 14:07:00'),
(5, 'KOR', 211, 32, 45, 3, '2020-05-08 02:47:38');

-- --------------------------------------------------------

--
-- Table structure for table `negara`
--

CREATE TABLE `negara` (
  `id_negara` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_negara` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `negara`
--

INSERT INTO `negara` (`id_negara`, `nama_negara`) VALUES
('CHN', 'China'),
('IDN', 'Indonesia'),
('KOR', 'Korea'),
('USA', 'Amerika Serikat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_statik`
--
ALTER TABLE `data_statik`
  ADD PRIMARY KEY (`id`),
  ADD KEY `negara` (`id_negara`);

--
-- Indexes for table `negara`
--
ALTER TABLE `negara`
  ADD PRIMARY KEY (`id_negara`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_statik`
--
ALTER TABLE `data_statik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data_statik`
--
ALTER TABLE `data_statik`
  ADD CONSTRAINT `data_statik_ibfk_1` FOREIGN KEY (`id_negara`) REFERENCES `negara` (`id_negara`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
